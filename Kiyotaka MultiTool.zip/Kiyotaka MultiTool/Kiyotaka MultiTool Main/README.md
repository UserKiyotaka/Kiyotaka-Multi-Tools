# Kiyotaka Multi-tool
Kiyotaka Multi-Tool is a Open-Source Multitool written by myself, contains a lot of things such as a ip lookup, dox tool etc. Enjoy! :)



It contains:

1. Ip pinger
2. Ip stresser
3. Ip lookup
4. Port Scanner
5. Open putty
6. Dox tool
7. Open cyberhub (Hacking tools and more)
8. Open vedbox (Useful tools)
9. Random IP generator
10. Fortnite Aimbot/Wallhack
11. EXIT 
